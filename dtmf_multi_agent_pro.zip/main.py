from agents.design_agent import DesignAgent
from agents.simulation_agent import SimulationAgent
from agents.evaluation_agent import EvalAgent
from agents.optimization_agent import OptAgent

design=DesignAgent()
sim=SimulationAgent()
eval_agent=EvalAgent()
opt=OptAgent()

digit='5'
sig,fs=design.generate(digit)
noisy=sim.add_awgn(sig,5)
taps=opt.search(sim,eval_agent,noisy,fs,(770,1336))
y=sim.bandpass(noisy,fs,taps)
pred=eval_agent.detect(y,fs)

print("True:",digit)
print("Pred:",pred)
print("Best taps:",taps)
