from agents.design_agent import DesignAgent
from agents.simulation_agent import SimulationAgent
from agents.evaluation_agent import EvalAgent
from agents.optimization_agent import OptAgent
from utils.plotting import plot_snr_curve

design=DesignAgent()
sim=SimulationAgent()
eval_agent=EvalAgent()
opt=OptAgent()

digit='5'
snrs=list(range(-5,11,3))
accs=[]

sig,fs=design.generate(digit)

for snr in snrs:
    noisy=sim.add_awgn(sig,snr)
    taps=opt.search(sim,eval_agent,noisy,fs,(770,1336))
    y=sim.bandpass(noisy,fs,taps)
    pred=eval_agent.detect(y,fs)
    accs.append(1 if pred==(770,1336) else 0)

plot_snr_curve(snrs,accs,"assets/snr_curve.png")
print("Done, see assets/snr_curve.png")
