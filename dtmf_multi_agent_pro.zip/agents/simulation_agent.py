import numpy as np
from scipy.signal import firwin, lfilter

class SimulationAgent:
    def add_awgn(self, signal, snr_db):
        sp = np.mean(signal**2)
        npow = sp/(10**(snr_db/10))
        noise = np.random.normal(0, np.sqrt(npow), len(signal))
        return signal+noise

    def bandpass(self, signal, fs, taps):
        coeff = firwin(taps, [600,1800], pass_zero=False, fs=fs)
        return lfilter(coeff,1,signal)
