class OptAgent:
    def search(self, sim, eval_agent, signal, fs, target):
        best=None;best_acc=0
        for t in [51,101,151,201]:
            y=sim.bandpass(signal,fs,t)
            pred=eval_agent.detect(y,fs)
            acc=1 if pred==target else 0
            if acc>best_acc:
                best_acc=acc;best=t
        return best
