import numpy as np

def goertzel(x, fs, f):
    N=len(x)
    k=int(0.5+N*f/fs)
    w=2*np.pi*k/N
    coeff=2*np.cos(w)
    q0=q1=q2=0
    for s in x:
        q0=coeff*q1-q2+s
        q2=q1
        q1=q0
    return q1*q1+q2*q2-q1*q2*coeff

class EvalAgent:
    def detect(self, signal, fs):
        lows=[697,770,852,941]
        highs=[1209,1336,1477]
        ls=[goertzel(signal,fs,f) for f in lows]
        hs=[goertzel(signal,fs,f) for f in highs]
        return lows[int(np.argmax(ls))], highs[int(np.argmax(hs))]
