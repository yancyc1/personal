import numpy as np

DTMF_FREQS = {
    '1': (697, 1209), '2': (697, 1336), '3': (697, 1477),
    '4': (770, 1209), '5': (770, 1336), '6': (770, 1477),
    '7': (852, 1209), '8': (852, 1336), '9': (852, 1477),
    '0': (941, 1336)
}

class DesignAgent:
    def generate(self, digit, fs=8000, duration=0.5):
        t = np.linspace(0, duration, int(fs*duration), endpoint=False)
        f1, f2 = DTMF_FREQS[digit]
        return np.sin(2*np.pi*f1*t)+np.sin(2*np.pi*f2*t), fs
