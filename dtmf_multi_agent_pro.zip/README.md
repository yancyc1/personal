# Multi-Agent DTMF System (High-Quality Version)

## Highlights
- Multi-Agent architecture (Design / Simulation / Evaluation / Optimization)
- Closed-loop reasoning pipeline
- Automatic parameter optimization
- SNR performance visualization

## Run
```bash
pip install -r requirements.txt
python main.py
python experiments/run_experiment.py
```

## Output
- assets/snr_curve.png
