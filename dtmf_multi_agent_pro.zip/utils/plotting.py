import matplotlib.pyplot as plt
import numpy as np

def plot_snr_curve(snrs, accs, path):
    plt.figure()
    plt.plot(snrs, accs, marker='o')
    plt.xlabel("SNR (dB)")
    plt.ylabel("Accuracy")
    plt.title("SNR vs Accuracy")
    plt.savefig(path)
